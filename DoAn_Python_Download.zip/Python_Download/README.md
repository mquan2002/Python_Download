Đề tài
- Phát triển phần mềm tải video từ Youtube hoặc Facebook
- Ngôn ngữ : Python3
- Hệ điều hành : Ubuntu - Linux - VMware
- Thành viên :
1. Hoàng Triệu Minh Quân - 3120410432 
2. Nguyễn Tuẫn Mẫn -
3. Bùi Minh Ngọc -

Cách sử dụng phần mềm : 
- Youtube : Lấy link url trực tiếp bỏ vào và chọn thư mục tải về
- Facebook : Chưa có cách lấy url trực tiếp nên chưa tải được
